﻿#include <iostream>
#include <string>
using namespace std;

// ========== Utility Functions ==========

// Formats a number as a 2-digit string (e.g., 7 → "07")
string twoDigitString(unsigned int n) {
    if (n < 10)
        return "0" + to_string(n);
    else
        return to_string(n);
}

// Returns a string of `n` repeated characters `c` (e.g., nCharString(5, '*') → "*****")
string nCharString(size_t n, char c) {
    return string(n, c);
}

// ========== Clock Formatting ==========

// 24-hour time format (hh:mm:ss)
string formatTime24(unsigned int h, unsigned int m, unsigned int s) {
    return twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s);
}

// 12-hour time format (hh:mm:ss A M / P M)
string formatTime12(unsigned int h, unsigned int m, unsigned int s) {
    string period = (h < 12) ? " A M" : " P M";
    unsigned int displayHour = h % 12;
    if (displayHour == 0) displayHour = 12;

    return twoDigitString(displayHour) + ":" + twoDigitString(m) + ":" + twoDigitString(s) + period;
}

// ========== Time State Variables ==========
unsigned int hour = 0;
unsigned int minute = 0;
unsigned int second = 0;

// ========== Getters & Setters ==========

unsigned int getHour() { return hour; }
unsigned int getMinute() { return minute; }
unsigned int getSecond() { return second; }

void setHour(unsigned int h) { hour = h; }
void setMinute(unsigned int m) { minute = m; }
void setSecond(unsigned int s) { second = s; }

// ========== Time Manipulation ==========

void addOneHour() {
    if (getHour() < 23)
        setHour(getHour() + 1);
    else
        setHour(0);
}

void addOneMinute() {
    if (getMinute() < 59)
        setMinute(getMinute() + 1);
    else {
        setMinute(0);
        addOneHour();
    }
}

void addOneSecond() {
    if (getSecond() < 59)
        setSecond(getSecond() + 1);
    else {
        setSecond(0);
        addOneMinute();
    }
}

// ========== Menu Utilities ==========

int getMenuChoice(unsigned int maxChoice) {
    int choice = 0;
    while (true) {
        cin >> choice;
        if (choice >= 1 && choice <= (int)maxChoice)
            return choice;
    }
}

// ========== Display Clocks ==========

void displayClocks(unsigned int h, unsigned int m, unsigned int s) {
    cout << nCharString(27, '*') << "   " << nCharString(27, '*') << endl;

    cout << "*" << nCharString(6, ' ') << "12-HOUR CLOCK" << nCharString(6, ' ') << "*"
        << "   "
        << "*" << nCharString(6, ' ') << "24-HOUR CLOCK" << nCharString(6, ' ') << "*" << endl;

    cout << endl;

    cout << "*" << nCharString(6, ' ') << formatTime12(h, m, s) << nCharString(7, ' ') << "*"
        << "   "
        << "*" << nCharString(8, ' ') << formatTime24(h, m, s) << nCharString(9, ' ') << "*" << endl;

    cout << nCharString(27, '*') << "   " << nCharString(27, '*') << endl;
}

// ========== Main Menu Loop ==========

void mainMenu() {
    bool running = true;
    while (running) {
        displayClocks(getHour(), getMinute(), getSecond());
        cout << "1 - Add One Hour\n";
        cout << "2 - Add One Minute\n";
        cout << "3 - Add One Second\n";
        cout << "4 - Exit Program\n";
        int choice = getMenuChoice(4);
        switch (choice) {
        case 1: addOneHour(); break;
        case 2: addOneMinute(); break;
        case 3: addOneSecond(); break;
        case 4: running = false; break;
        }
    }
}

// ========== Program Entry Point ==========

int main() {
    mainMenu();
    return 0;
}
